<x-layouts.main>
    @php
        $paid = false;
        if (auth()->check()){
            $paid = auth()->user()->isAllowedToView();
        }
        $paid = true;
    @endphp

    @if($paid)
        @livewire('fashion-listing-component')
    @else
        @livewire('client-pay-component')
    @endif

</x-layouts.main>
